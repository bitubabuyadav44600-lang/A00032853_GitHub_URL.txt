# CMPN202 Operating Systems Coursework Journal

**Student Name:** Bitu Babu Yadav  
**Student ID:** A00032853  
**Module:** CMPN202 – Operating Systems  
**Submission:** GitHub Pages Journal (7 Weeks)

---

## Project Overview
This journal documents the design, deployment, security configuration, and performance evaluation of a Linux-based server system administered remotely from a workstation. The project follows a structured, week-by-week approach aligned with the CMPN202 coursework brief.

**System Summary:**
- Server OS: *(to be filled)*
- Workstation OS: *(to be filled)*
- Virtualisation Platform: VirtualBox
- Network Type: Isolated internal network

---

## Table of Contents
- [Week 1 – System Planning & OS Selection
- [Week 2 – Security Planning & Testing Methodology
- [Week 3 – Application Selection & Installation](#week-3--application-selection--installatio
- [Week 4 – Core Deployment & Foundational Security](#week-4--core-deployment--foundational-security)
- [Week 5 – Advanced Security & Automation](#week-5--advanced-security--automation)
- [Week 6 – Performance Evaluation & Optimisation](#week-6--performance-evaluation--optimisation)
- [Week 7 – Security Audit & System Evaluation](#week-7--security-audit--system-evaluation)

---

## Week 7 – Security Audit & System Evaluation### Objectives
To audit the system security posture and evaluate overall configuration effectiveness.

### Lynis Audit
```bash
sudo apt install lynis
sudo lynis audit system
```
Initial and improved scores were documented after remediation.

### Network Scan (Isolated Network Only)
```bash
nmap <server-ip>
```

### Service Audit
```bash
systemctl list-units --type=service --state=running
```
All active services were reviewed and justified.

### Final Evaluation
The system demonstrates secure remote administration, effective performance tuning, and compliance with all mandatory assessment requirements.

---

## Conclusion
This project demonstrates secure remote administration, performance monitoring, and optimisation of a Linux server system. Security controls were balanced with performance requirements, supported by quantitative evidence and structured testing.

---

## Repository Structure
```
/docs
  index.md
  week1.md
  week2.md
  week3.md
  week4.md
  week5.md
  week6.md
  week7.md
/images
/scripts
```

---

## Declaration
I confirm that this work is my own and complies with university academic integrity regulations.