# CMPN202 Operating Systems Coursework Journal

**Student Name:** Bitu Babu Yadav  
**Student ID:** A00032853  
**Module:** CMPN202 – Operating Systems  
**Submission:** GitHub Pages Journal (7 Weeks)

---

## Project Overview
This journal documents the design, deployment, security configuration, and performance evaluation of a Linux-based server system administered remotely from a workstation. The project follows a structured, week-by-week approach aligned with the CMPN202 coursework brief.

**System Summary:**
- Server OS: *(to be filled)*
- Workstation OS: *(to be filled)*
- Virtualisation Platform: VirtualBox
- Network Type: Isolated internal network

---

## Table of Contents
- [Week 1 – System Planning & OS Selection
- [Week 2 – Security Planning & Testing Methodology
- [Week 3 – Application Selection & Installation](#week-3--application-selection--installatio
- [Week 4 – Core Deployment & Foundational Security](#week-4--core-deployment--foundational-security)
- [Week 5 – Advanced Security & Automation](#week-5--advanced-security--automation)
- [Week 6 – Performance Evaluation & Optimisation](#week-6--performance-evaluation--optimisation)
- [Week 7 – Security Audit & System Evaluation](#week-7--security-audit--system-evaluation)

---

## Week 4 – Core Deployment & Foundational Security### Objectives
To deploy the server securely and implement mandatory foundational security controls.

### SSH Key-Based Authentication
```bash
ssh-keygen -t ed25519
ssh-copy-id user@server-ip
```
Password authentication and root login were disabled in `/etc/ssh/sshd_config`.

### Firewall Configuration (UFW)
```bash
sudo ufw default deny incoming
sudo ufw allow from <workstation-ip> to any port 22
sudo ufw enable
sudo ufw status verbose
```

### User and Privilege Management
```bash
sudo adduser adminuser
sudo usermod -aG sudo adminuser
```

### Evidence
Screenshots demonstrate SSH access, firewall rules, and configuration changes, all performed remotely.

---