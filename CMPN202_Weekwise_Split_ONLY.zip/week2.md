# CMPN202 Operating Systems Coursework Journal

**Student Name:** Bitu Babu Yadav  
**Student ID:** A00032853  
**Module:** CMPN202 – Operating Systems  
**Submission:** GitHub Pages Journal (7 Weeks)

---

## Project Overview
This journal documents the design, deployment, security configuration, and performance evaluation of a Linux-based server system administered remotely from a workstation. The project follows a structured, week-by-week approach aligned with the CMPN202 coursework brief.

**System Summary:**
- Server OS: *(to be filled)*
- Workstation OS: *(to be filled)*
- Virtualisation Platform: VirtualBox
- Network Type: Isolated internal network

---

## Table of Contents
- [Week 1 – System Planning & OS Selection
- [Week 2 – Security Planning & Testing Methodology
- [Week 3 – Application Selection & Installation](#week-3--application-selection--installatio
- [Week 4 – Core Deployment & Foundational Security](#week-4--core-deployment--foundational-security)
- [Week 5 – Advanced Security & Automation](#week-5--advanced-security--automation)
- [Week 6 – Performance Evaluation & Optimisation](#week-6--performance-evaluation--optimisation)
- [Week 7 – Security Audit & System Evaluation](#week-7--security-audit--system-evaluation)

---

## Week 2 – Security Planning & Testing Methodology### Objectives
This week focused on planning security controls and defining a structured performance testing methodology.

### Security Configuration Checklist
Planned security measures include:
- SSH key-based authentication
- Disabling SSH password login
- Firewall-based access control
- Mandatory access control (AppArmor)
- Automatic security updates
- Least-privilege user management

### Threat Model
| Threat | Risk | Mitigation |
|------|------|-----------|
| Brute-force SSH | High | SSH keys + fail2ban |
| Vulnerable packages | Medium | Automatic updates |
| Network intrusion | High | Firewall IP restriction |

### Performance Testing Plan
Performance will be evaluated using remote monitoring tools over SSH, measuring CPU, memory, disk I/O, and network usage under baseline and load conditions.

------|-----------|---------------------|
| Brute-force SSH attacks | High | SSH key-based authentication and fail2ban |
| Unpatched vulnerabilities | Medium | Automatic security updates |
| Unauthorised network access | High | Firewall IP-based access control |

### Security Controls Planned
- Disable SSH password authentication
- Restrict SSH access to workstation IP only
- Enforce least-privilege user access
- Enable mandatory access control

### Testing Methodology
Performance and security testing will be conducted using:
- CPU, memory, disk, and network monitoring tools
- Baseline measurements before optimisation
- Comparative testing after security and performance tuning

This structured methodology ensures reliable and repeatable results.

------|------|------------|
| Brute-force SSH | High | SSH keys + fail2ban |
| Unpatched software | Medium | Automatic updates |
| Unauthorised access | High | Firewall rules |

### Testing Methodology
- Performance metrics to be measured
- Tools to be used

---