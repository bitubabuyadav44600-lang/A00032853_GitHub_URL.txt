# CMPN202 Operating Systems Coursework Journal

**Student Name:** Bitu Babu Yadav  
**Student ID:** A00032853  
**Module:** CMPN202 – Operating Systems  
**Submission:** GitHub Pages Journal (7 Weeks)

---

## Project Overview
This journal documents the design, deployment, security configuration, and performance evaluation of a Linux-based server system administered remotely from a workstation. The project follows a structured, week-by-week approach aligned with the CMPN202 coursework brief.

**System Summary:**
- Server OS: *(to be filled)*
- Workstation OS: *(to be filled)*
- Virtualisation Platform: VirtualBox
- Network Type: Isolated internal network

---

## Table of Contents
- [Week 1 – System Planning & OS Selection
- [Week 2 – Security Planning & Testing Methodology
- [Week 3 – Application Selection & Installation](#week-3--application-selection--installatio
- [Week 4 – Core Deployment & Foundational Security](#week-4--core-deployment--foundational-security)
- [Week 5 – Advanced Security & Automation](#week-5--advanced-security--automation)
- [Week 6 – Performance Evaluation & Optimisation](#week-6--performance-evaluation--optimisation)
- [Week 7 – Security Audit & System Evaluation](#week-7--security-audit--system-evaluation)

---

## Week 3 – Application Selection & Installation### Objectives
To select representative applications for performance testing and install them using secure SSH-based administration.

### Application Selection Matrix
| Application | Workload Type | Justification |
|------------|--------------|---------------|
| stress-ng | CPU/RAM | Generates controlled system load |
| sysbench | CPU/Memory | Benchmarking and comparison |
| iperf3 | Network | Measures bandwidth and latency |

### Installation Commands
All applications were installed via SSH:
```bash
sudo apt update
sudo apt install stress-ng sysbench iperf3
```

### Expected Resource Usage
- stress-ng: High CPU and memory utilisation
- sysbench: Predictable benchmarking load
- iperf3: Network throughput stress

### Monitoring Strategy
System metrics are collected using tools such as `top`, `htop`, `free`, `vmstat`, and `iftop` during tests.

------------|--------|----------------|
| stress-ng | Synthetic load testing | CPU & RAM |
| sysbench | Benchmarking | CPU & Memory |
| iperf3 | Network testing | Network throughput |

### Installation
Applications were installed securely via SSH using the package manager:
```bash
sudo apt update
sudo apt install stress-ng sysbench iperf3
```

### Expected Performance Impact
- **stress-ng:** High CPU and memory utilisation under load
- **sysbench:** Consistent benchmarking results for comparison
- **iperf3:** Measurement of network bandwidth and latency

These tools provide quantitative data required for later optimisation analysis.

------------|--------|----------------|
| *(App 1)* | CPU test | CPU |
| *(App 2)* | Memory test | RAM |
| *(App 3)* | Network test | Network |

### Installation Commands
```bash
sudo apt install <package-name>
```

### Expected Performance Impact
*(Brief explanation per application)*

---