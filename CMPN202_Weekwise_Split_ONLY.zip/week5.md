# CMPN202 Operating Systems Coursework Journal

**Student Name:** Bitu Babu Yadav  
**Student ID:** A00032853  
**Module:** CMPN202 – Operating Systems  
**Submission:** GitHub Pages Journal (7 Weeks)

---

## Project Overview
This journal documents the design, deployment, security configuration, and performance evaluation of a Linux-based server system administered remotely from a workstation. The project follows a structured, week-by-week approach aligned with the CMPN202 coursework brief.

**System Summary:**
- Server OS: *(to be filled)*
- Workstation OS: *(to be filled)*
- Virtualisation Platform: VirtualBox
- Network Type: Isolated internal network

---

## Table of Contents
- [Week 1 – System Planning & OS Selection
- [Week 2 – Security Planning & Testing Methodology
- [Week 3 – Application Selection & Installation](#week-3--application-selection--installatio
- [Week 4 – Core Deployment & Foundational Security](#week-4--core-deployment--foundational-security)
- [Week 5 – Advanced Security & Automation](#week-5--advanced-security--automation)
- [Week 6 – Performance Evaluation & Optimisation](#week-6--performance-evaluation--optimisation)
- [Week 7 – Security Audit & System Evaluation](#week-7--security-audit--system-evaluation)

---

## Week 5 – Advanced Security & Automation### Objectives
To implement advanced security controls and develop automation scripts for verification and monitoring.

### Mandatory Access Control (AppArmor)
```bash
sudo aa-status
```
AppArmor profiles were enforced and verified.

### Automatic Security Updates
```bash
sudo apt install unattended-upgrades
sudo dpkg-reconfigure unattended-upgrades
```

### fail2ban Configuration
```bash
sudo apt install fail2ban
sudo systemctl enable fail2ban
sudo systemctl status fail2ban
```

### Security Baseline Script (Server)
`security-baseline.sh` verifies SSH, firewall, updates, AppArmor, and fail2ban status. Each command includes explanatory comments.

### Monitoring Script (Workstation)
`monitor-server.sh` connects via SSH and records CPU, memory, disk, and network statistics.

---